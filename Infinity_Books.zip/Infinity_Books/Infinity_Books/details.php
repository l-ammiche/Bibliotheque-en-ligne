<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8" />
        <title>Plus d'informations</title>
        <meta name="author" content="Ahcene ALOUANE, Lounis AMMICHE" />
        <meta name="lieu" content="CY Cergy Paris Université" />
        <meta name="date" content="" />
        <meta name="keyword" content="Books, Infinity Books, Projet, PHP, HTML, Cyu, 2023, API, Book, Livre, Livres, JSON, Cookie" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />



        
        <style>
            body {
                font-family: 'Roboto', sans-serif;
                background-color: #f5f5f5;
                color: #333;
                line-height: 1.6;
            }

            main {
                max-width: 900px;
                margin: 1.5rem auto;
                padding: 1rem;
                background-color: #DDDDDD;
                box-shadow: 0 4px 6px rgb(210, 210, 210);
            }

            button {
                background-color: #3f51b5;
                color: #fff;
                padding: 0.5rem 1rem;
                border: none;
                cursor: pointer;
                font-size: 1rem;
                margin-bottom: 1rem;
                border-radius: 5px;
            }

            button:hover {
                background-color: #283593;
                
            }

            h1 {
                font-size: 3rem;
                margin-bottom: 5rem;
                
            }

            .book-details {
                display: flex;
                flex-wrap: wrap;
                gap: 1rem;
            }

            .book-image {
                flex: 0 0 200px;
            }

            .book-image img {
                max-width: 100%;
                max-height: 300px;
                object-fit: cover;
                border: 2px solid rgb(0, 0, 0);
            }

            h2 {
                font-size: 1.5rem;
                margin-bottom: 0.5rem;
            }

            span {
                display: block;
                font-size: 1.1rem;
                margin-bottom: 0.5rem;
            }

            strong {
                font-weight: 500;
            }

            .button {
                background-color: #3f51b5;
                color: #fff;
                padding: 0.5rem 1rem;
                text-decoration: none;
                border-radius: 4px;
            }

            .button:hover {
                background-color: #283593;
            }

           
        </style>
        <script>
            function setCookie(cname, cvalue, exdays) {
                var d = new Date();
                d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                var expires = "expires="+d.toUTCString();
                document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
            }

            function deleteCookie(cname) {
                document.cookie = cname + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
            }

            function updateBookCookie(bookInfo) {
                deleteCookie("lastBook");
                setCookie("lastBook", JSON.stringify(bookInfoC), 30);
            }
        </script>
    </head>

    <body>
        <header>

        </header>

        <main>
            <button onclick="goBack()" title="Revenir à la page précédente">Retour</button>
            <?php
                // Code nécessaire pour récupérer les informations des livres
                if (isset($_GET['id'])) {
                    $id = $_GET['id'];
                    $apiKey = 'AIzaSyDLL3CRwM2_DF-bRow-WYv8yYzBEZQuBzQ';
                    $url = "https://www.googleapis.com/books/v1/volumes/$id?key=$apiKey";

                    $response = file_get_contents($url);
                    $book = json_decode($response, true);

                    $title = isset($book['volumeInfo']['title']) ? $book['volumeInfo']['title'] : 'Titre indisponible';
                    $id = isset($book['id']) ? $book['id'] : 'ID indisponible';
                    $authors = isset($book['volumeInfo']['authors']) ? implode(', ', $book['volumeInfo']['authors']) : 'Auteur(s) indisponible(s)';
                    $description = isset($book['volumeInfo']['description']) ? htmlentities(strip_tags($book['volumeInfo']['description'])) : 'Description indisponible';
                    if (isset($book['volumeInfo']['imageLinks']['thumbnail'])) {
                        $image = $book['volumeInfo']['imageLinks']['thumbnail'];
                    } else {
                        $image = 'images/none.png';
                    }
                    $isbn = isset($book['volumeInfo']['industryIdentifiers'][0]['identifier']) ? $book['volumeInfo']['industryIdentifiers'][0]['identifier'] : 'ISBN indisponible';
                    $publishedDate = isset($book['volumeInfo']['publishedDate']) ? $book['volumeInfo']['publishedDate'] : 'Date de publication indisponible';
                    $publisher = isset($book['volumeInfo']['publisher']) ? $book['volumeInfo']['publisher'] : 'Maison d\'édition indisponible';
                    $category = isset($book['volumeInfo']['categories'][0]) ? $book['volumeInfo']['categories'][0] : 'Catégorie indisponible';
                    $pageCount = isset($book['volumeInfo']['pageCount']) ? $book['volumeInfo']['pageCount'] : 'Nombre de pages indisponible';
                    $averageRating = isset($book['volumeInfo']['averageRating']) ? $book['volumeInfo']['averageRating'] : 'Note moyenne indisponible';
                    $language = isset($book['volumeInfo']['language']) ? $book['volumeInfo']['language'] : 'Langue indisponible';
                    $country = isset($book['saleInfo']['country']) ? $book['saleInfo']['country'] : 'Pays indisponible';
                    $previewLink = isset($book['volumeInfo']['previewLink']) ? $book['volumeInfo']['previewLink'] : 'Lien de lecture en ligne indisponible';
                    $pdfLink = '';
                    if (isset($book['accessInfo']) && isset($book['accessInfo']['pdf']) && isset($book['accessInfo']['pdf']['downloadLink'])) {
                        $pdfLink = $book['accessInfo']['pdf']['downloadLink'];
                    }

                    
                    
                    // Création du tableau contenant les informations du livre
                    $bookInfo = array(
                        'id' => $id,
                        'title' => $title,
                        'authors' => $authors,
                        'isbn' => $isbn,
                        'occur'=> 1,        
                    );

                    $bookInfoC = array(
                        'title' => $title,
                        'authors' => $authors,
                        'isbn' => $isbn,
                        'image'=>  $image,
                        'id' => $id,
                    );



                    // Ouvrir le fichier CSV
                    $file = 'statBooks.csv';
                    $fp = fopen($file, 'r+');
        
                    // Initialiser la variable pour suivre si l'ID est trouvé ou non
                    $found = false;
                    
                    // initialisation du numéro de ligne
                    $line_number = 0;
                    // Boucler sur chaque ligne du fichier CSV
                    while ($row = fgetcsv($fp)) {

                        // Vérifier si l'ID est trouvé dans la première colonne
                        if ($row[1] === $title) {
                            // Incrémenter la valeur de la 5ème colonne ("occur") de la ligne correspondante
                            $row[4]++;
                            // retour à la ligne précédente
                            fseek($fp, 0, SEEK_SET);
                            for ($i = 0; $i < $line_number; $i++) {
                                fgetcsv($fp);
                            }
                            // Réécrire la ligne mise à jour dans une autre ligne du fichier CSV
                            fputcsv($fp, $row);
                            // Mettre à jour la variable pour suivre si l'ID est trouvé
                            $found = true;
                            // Sortir de la boucle pour éviter de parcourir le reste du fichier
                            break;
                        }
                        // incrémentation du numéro de ligne
                        $line_number++;
                    }
                    
                    // Si l'ID n'est pas trouvé, ajouter une nouvelle ligne avec les informations de $bookInfo
                    if (!$found) {
                    // ajout de la nouvelle ligne dans le fichier
                        fseek($fp, 0, SEEK_END);
                        fputcsv($fp, $bookInfo);
                    }
        
                    // Fermer le fichier CSV
                    fclose($fp);



                    // Création du cookie
                    $cookie_name = "book_info";
                    $cookie_value = json_encode($bookInfoC);
                    setcookie($cookie_name, $cookie_value);

                    
                    $image= str_replace('&', '&amp;', $image);
                    
                     // Mise à jour du cookie avec les informations du livre actuel
                     echo "<script>updateBookCookie(" . json_encode($bookInfoC) . ");</script> \n";

                    // Vérification si le cookie existe et suppression de l'ancien livre
                    //if(isset($_COOKIE[$cookie_name])) {
                    //   $old_book_info = json_decode($_COOKIE[$cookie_name], true);
                    //   if($old_book_info['id'] != $bookInfo['id']) {
                    //       setcookie($cookie_name, "", time() - 3600);
                    //   }
                    // }


                    
                    $previewLink = str_replace('&', '&amp;',  $previewLink);
                    $category = str_replace('&', '&amp;', $category);
                    
                   

                    echo "<h1>Plus de détails sur "."'".$title."'"."</h1> \n";

                    echo "<section class='book-details'> \n";
                    if ($image != '') {
                        echo "<div class='book-image'> \n";
                        echo "<img src='$image' alt='Image de couverture de livre' /> \n";
                        echo "</div> \n";
                    }
                    echo "<h2>$title</h2> \n";
                    echo "<span><strong>Par</strong> $authors</span>\n";
                    echo "<span><strong>ID de livre: </strong> $id</span>\n";
                    echo "<span><strong>Description: </strong> $description</span>\n";
                    echo "<span><strong>ISBN: </strong> $isbn</span> \n";
                    echo "<span><strong>Date de publication: </strong> $publishedDate</span> \n";
                    echo "<span><strong>Maison d'édition: </strong> $publisher</span> \n";
                    echo "<span><strong>Catégorie: </strong> $category</span> \n";
                    echo "<span><strong>Nombre de pages: </strong> $pageCount</span> \n";
                    echo "<span><strong>Note moyenne: </strong> $averageRating</span> \n";
                    echo "<span><strong>Langue: </strong> $language</span> \n";
                    //echo "<span><strong>Pays: </strong> $country</span> \n";
                    echo "<span> \n<a href='$previewLink' class='button' target='_blank' title='Lien pour acheter ou lire des extraits du livre'>Acheter/Lire des extraits</a> \n</span> \n";
                   
                    if (!empty($pdfLink) && filter_var($pdfLink, FILTER_VALIDATE_URL)) {
                        echo "<span>\n <a href='$pdfLink' class='button' title='Télécharger ce livre en PDF'>Télécharger en PDF</a>\n</span> \n";
                    } else {
                        echo "<span>Lien de téléchargement PDF indisponible.</span>\n";
                    }                    
                    echo "</section>\n";
                } else {
                    echo "<span>ID du livre manquant. Veuillez effectuer une recherche.</span>\n";
                }
            ?>
        </main>

        <footer>
        </footer>

        <script>
            function goBack() {
                window.history.back();
            }
        </script>
    </body>
</html>