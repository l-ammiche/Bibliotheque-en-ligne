<?php
if (isset($_GET['style']) && ($_GET['style'] == 'style_clair' || $_GET['style'] == 'styles')) {
  // Crée un cookie pour enregistrer la préférence de l'utilisateur
  setcookie('style', $_GET['style'], time() + (86400 * 30), '/');
  header('Location: '.$_SERVER['PHP_SELF']);
  exit;
}
// Vérifie si l'utilisateur a déjà choisi un mode de couleur
if (isset($_COOKIE['style'])) {
  // Si oui, inclure le fichier CSS correspondant
  if ($_COOKIE['style'] == 'style_clair') {
    $stylesheet = 'style_clair.css';
  } else {
    $stylesheet = 'styles.css';
  }
} else {
  // Si non, utiliser le mode clair par défaut
  $stylesheet = 'styles.css';
}
if (isset($id, $title, $authors, $description, $image, $isbn, $publishedDate, $publisher)) {
  $row = array($id, $title, $authors, $description, $image, $isbn, $publishedDate, $publisher);
  $file = fopen('books.csv', 'a');
  fputcsv($file, $row);
  fclose($file);
}
?>
<?php
    $style = '
    <style>
   


    main {
        padding: 40px;
      }
   

    .bloc ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }

    .bloc li {
      padding: 8px 0;
    }

    .bloc li a {
      color: #000000;
      text-decoration: none;
    }

    .bloc li a:hover {
      text-decoration: underline;
    }

    figure {
      text-align: center;
    }
    
    img {
      display: block;
      margin: 0 auto;
    }

  </style>
    ';
    $title="Plan du site" ;
    $description="C'est est une page web qui répertorie toutes les pages d'un site web et leur structure. Cette page permet aux visiteurs de comprendre l'organisation et la hiérarchie des pages du site, ainsi que de naviguer facilement entre les différentes sections." ; 
    require "./include/header.inc.php";
?>

        <main>

            <aside>
                <ul class="switch-mode">
                <li>
                    <a href="?style=styles" class="day-mode active" title="Activer le mode nuit">
                    <img src="images/night.png" alt="Mode Nuit" />
                    </a>
                </li>
                <li>
                    <a href="?style=style_clair" class="night-mode" title="activer le mode jour">
                    <img src="images/mode-jour.png" alt="Mode Jour" />
                    </a>
                </li>
                <li>
                    <a href="#" class="haut" title="Revenir en haut de page">
                    <img src="images/haut.png" alt="flèche vers le haut" />
                    </a>
                </li>
                </ul>
            </aside>
            
            <h1>Plan du site</h1>

            <section class="bloc">
                <h2>Pages principales</h2>
                <ul>
                    <li><a href="index.php" title="Revenir à la page d'acceuil du site.">Infinity Books</a></li>
                    <li><a href="page-recherches.php" title="Accéder à la page de recherches.">Page de recherche</a></li>
                    <li><a href="bibliotheque.php" title="Retrouver ma collection de livres.">Ma bibliothèque</a></li>
                    <li><a href="tendances.php" title="Retrouver les livres tendance actuelle.">Tendance</a></li>
                    <li><a href="statistiques.php" title="Visionner des statistiques concernant Infinity Books">Statistiques</a></li>
                </ul>
            </section>

            <section class="bloc">
                <h2>Autres pages</h2>
                <ul>
                    <li><a href="auteurs.php" title="Retrouver la page didiée aux auteurs">La page des auteurs</a></li>
                    <li><a href="cv-alouane.html" title="Retrouver le CV à l'auteur Ahcene ALOUANE">Ahcene ALOUANE</a></li>
                    <li><a href="cv-ammiche.html" title="Retrouver le CV à l'auteur Lounis AMMICHE">Lounis AMMICHE</a></li>
                    <li><a href="tech.php" title="Accéder à un coin pour les programmeurs">Geeky side</a></li>
                    <li><a href="a-propos.php" title="Accéder à la page à propos du site">À propos</a></li>
                </ul>
            </section>

            <section>
                <h2>Schéma du plan du site</h2>
                <figure class="plan">
                  <img src="/images/plan.png" alt="Schéma du plan du site" width="1000"/>
                  <figure>Schéma du plan de site Infinity Books</figure>
                </figure>
            </section>
        </main>



<?php
    require "./include/footer.inc.php"; 
?>