<?php
    $style = '';
    $title="Auteurs" ;
    $description="Cette page est dédiée pour présenter l'équipe d'auteurs de ce projet, en affichant deux petites fiches d'informations sur les développeur du site Infinity Books, ces dernières sont des liens cliquables pour accéder à leur CVs. " ; 
    require "./include/header.inc.php";
?>

    <main>

    <aside>
            <ul class="switch-mode">
                <li>
                    <a href="?style=styles" class="day-mode active" title="Activer le mode nuit">
                    <img src="images/night.png" alt="Mode Nuit" />
                    </a>
                </li>
                <li>
                    <a href="?style=style_clair" class="night-mode" title="activer le mode jour">
                    <img src="images/mode-jour.png" alt="Mode Jour" />
                    </a>
                </li>
            </ul>
        </aside>

    <h1>Équipe du projet</h1>

	<div class="content1">
        <div class="nous" onclick="window.location.href='cv-alouane.html'" >
            <figure>
            <img src="/images/ahcene.png" alt="Avatar" class="avatar" />
            <figcaption></figcaption>
            </figure>
            <div class="info">
                <span class="titre">Ahcene ALOUANE</span>
                <ul>
                    <li><strong>Age : </strong> 20</li>
                    <li><strong>Niveau d'études :</strong> L2 Informatique</li>
                    <li><strong>Nationalité : </strong> Algérienne</li>
                    <li><strong>Email : </strong> ahcenealouane2003@gmail.com</li>
                </ul>
            </div>
        </div>
    
        <div class="nous" onclick="window.location.href='cv-ammiche.html'">
            <figure>
                <img src="images/lounis.png" alt="Avatar" class="avatar" />
                <figcaption></figcaption>
            </figure>
            <div class="info">
                <span class="titre">Lounis AMMICHE</span>
                <ul>
                    <li><strong>Age : </strong> 21 </li>
                    <li><strong>Niveau d'études :</strong> L2 Informatique</li>
                    <li><strong>Nationalité : </strong> Française</li>
                    <li><strong>Email :</strong>  lounis.ammiche@gmail.com</li>
                </ul>
            </div>
        </div>
    </div>

    </main>

<?php
    require "./include/footer.inc.php"; 
?>