<?php
    require "./include/functions.inc.php";
?>
<?php
if (isset($_GET['style']) && ($_GET['style'] == 'style_clair' || $_GET['style'] == 'styles')) {
  // Crée un cookie pour enregistrer la préférence de l'utilisateur
  setcookie('style', $_GET['style'], time() + (86400 * 30), '/');
  header('Location: '.$_SERVER['PHP_SELF']);
  exit;
}
// Vérifie si l'utilisateur a déjà choisi un mode de couleur
if (isset($_COOKIE['style'])) {
  // Si oui, inclure le fichier CSS correspondant
  if ($_COOKIE['style'] == 'style_clair') {
    $stylesheet = 'style_clair.css';
  } else {
    $stylesheet = 'styles.css';
  }
} else {
  // Si non, utiliser le mode clair par défaut
  $stylesheet = 'styles.css';
}
if (isset($id, $title, $authors, $description, $image, $isbn, $publishedDate, $publisher)) {
  $row = array($id, $title, $authors, $description, $image, $isbn, $publishedDate, $publisher);
  $file = fopen('books.csv', 'a');
  fputcsv($file, $row);
  fclose($file);
}
?>
<?php
    $style = '
    
    <style>
        #count {
            font-size: 10rem;
            font-weight: bold;
            text-align: center;
        }
    </style>
    
    ';
    $title="Statistiques de Infinity Books" ;
    $description="C'est la page des statistiques du site Infinity Books, elle affiche les 10 livres les plus recherchés (consultés) sur Infinity Books et notamment aussi le nombre de recherches effectuées sur le site aussi. " ; 
    require "./include/header.inc.php";
?>




            <main>

                <aside>
                    <ul class="switch-mode">
                    <li>
                        <a href="?style=styles" class="day-mode active" title="Activer le mode nuit">
                        <img src="images/night.png" alt="Mode Nuit" />
                        </a>
                    </li>
                    <li>
                        <a href="?style=style_clair" class="night-mode" title="activer le mode jour">
                        <img src="images/mode-jour.png" alt="Mode Jour" />
                        </a>
                    </li>
                    <li>
                        <a href="#" class="haut" title="Revenir en haut de page">
                        <img src="images/haut.png" alt="flèche vers le haut" />
                        </a>
                    </li>
                    </ul>
                </aside>

                <h1>Statistiques sur Infinity Books</h1>

                <section>
                    <h2>Les 10 livres les plus recherchés sur Infinty Books</h2>
                    <?php
                        // Lecture du fichier CSV
                        $file = fopen('statBooks.csv', 'r');
                        $data = array();
                        while (($line = fgetcsv($file)) !== FALSE) {
                            $data[] = $line;
                        }
                        fclose($file);

                        // Tri des livres par nombre de recherches décroissant et sélection des 10 premiers
                        function cmp($a, $b) {
                            return $b[4] - $a[4];
                        }
                        usort($data, "cmp");
                        $top_10 = array_slice($data, 0, 10);

                        // Création d'une liste de couleurs pour chaque livre
                        $colors = array('blue', 'green', 'red', 'cyan', 'magenta', 'yellow', 'black', 'purple', 'orange', 'gray');

                        // Génération du graphique de barres en JS
                        echo '<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>'."\n";
                        echo '<canvas id="myChart"></canvas>'."\n";
                        echo '<script>'."\n";
                        echo "var ctx = document.getElementById('myChart').getContext('2d');"."\n";
                        echo 'var myChart = new Chart(ctx, {'."\n";
                        echo "type: 'bar',"."\n";
                        echo 'data: {'."\n";
                        echo 'labels: ['."\n";
                        foreach ($top_10 as $book) {
                            echo '"' . $book[1] . '",'."\n";
                        }
                        echo '],'."\n";
                        echo 'datasets: [{'."\n";
                        echo 'data: ['."\n";
                        foreach ($top_10 as $book) {
                            echo $book[4] . ','."\n";
                        }
                        echo '],'."\n";
                        echo 'backgroundColor: ['."\n";
                        foreach ($colors as $color) {
                            echo '"' . $color . '",'."\n";
                        }
                        echo '],'."\n";
                        echo '}],'."\n";
                        echo '},'."\n";
                        echo 'options: {'."\n";
                        echo 'legend: {display: false},'."\n";
                        echo 'scales: {'."\n";
                        echo 'yAxes: [{'."\n";
                        echo 'ticks: {beginAtZero:true}'."\n";
                        echo '}]'."\n";
                        echo '}'."\n";
                        echo '}'."\n";
                        echo '});'."\n";
                        echo '</script>'."\n";

                        // Affichage des ISBN correspondant à chaque couleur
                        //for ($i = 0; $i < count($top_10); $i++) {
                        //   echo $colors[$i] . ' : ' . $top_10[$i][0] . '<br/>'."\n";
                        //}
                        ?>
                </section>

                <section>
                    <h2>Le nombre de recherches sur Infinity Books</h2>
                    <?php
                        // Lecture du nombre de recherches à partir du fichier texte
                        $search_count = intval(file_get_contents('data/searchs.txt'));
                    ?>                    
                    <div id="count"><span><?php echo $search_count ."!"; ?></span></div>
                </section>
                
                
            </main>
       
<?php
    require "./include/footer.inc.php"; 
?>