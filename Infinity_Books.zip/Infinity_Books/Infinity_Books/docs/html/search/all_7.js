var searchData=
[
  ['get_5fbooks_5fdata_5fand_5fsave_5fto_5fcsv',['get_books_data_and_save_to_csv',['../functions_8inc_8php.html#ad18b44a11cf7893c7a3c84d5ae22915a',1,'functions.inc.php']]],
  ['get_5fbooks_5fdata_5fand_5fsave_5fto_5fcsv_5fcollection',['get_books_data_and_save_to_csv_collection',['../functions_8inc_8php.html#a9d641a94f6a4b9290908d164be0d9945',1,'functions.inc.php']]],
  ['get_5fnavigateur',['get_navigateur',['../util_8inc_8php.html#a84af0b2f9c567359b2fbc6e48885e36d',1,'util.inc.php']]],
  ['get_5ftoday_5fdate',['get_today_date',['../util_8inc_8php.html#aff5907b7c18d7453e9447d64036d3387',1,'util.inc.php']]]
];
