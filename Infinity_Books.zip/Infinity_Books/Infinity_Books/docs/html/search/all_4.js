var searchData=
[
  ['details_2ephp',['details.php',['../details_8php.html',1,'']]]
];
