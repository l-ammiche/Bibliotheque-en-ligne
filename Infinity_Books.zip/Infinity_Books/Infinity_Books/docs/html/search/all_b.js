var searchData=
[
  ['read_5fbooks_5fdata_5ffrom_5fcsv',['read_books_data_from_csv',['../functions_8inc_8php.html#a9427b663cea17245dcc27de43eefe766',1,'functions.inc.php']]],
  ['read_5fbooks_5fdata_5ffrom_5fcsv_5fcollection',['read_books_data_from_csv_collection',['../functions_8inc_8php.html#a193c51e5eb006e87371ad8ea2f732dab',1,'functions.inc.php']]],
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]]
];
