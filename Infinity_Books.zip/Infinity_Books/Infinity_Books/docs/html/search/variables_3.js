var searchData=
[
  ['if',['if',['../header_8inc_8php.html#a5d2ee8bfb8318a3553cab531dcae78e9',1,'if():&#160;header.inc.php'],['../page-recherches_8php.html#adc4f08504750ec0b56a5b061af08f696',1,'if():&#160;page-recherches.php']]]
];
