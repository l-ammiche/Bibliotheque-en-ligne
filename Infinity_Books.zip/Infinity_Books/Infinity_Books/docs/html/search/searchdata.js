var indexSectionsWithContent =
{
  0: "$abcdefghiprstu",
  1: "abcdefhiprstu",
  2: "cgr",
  3: "$efi",
  4: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Fonctions",
  3: "Variables",
  4: "Pages"
};

