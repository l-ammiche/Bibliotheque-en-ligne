<?php

     /**
        * La fonction get_books_data_and_save_to_csv récupère des données de livres à partir d'une API en ligne, les traite et les stocke dans un fichier CSV nommé tendancesBooks. 
        *
        * @param string $apiUrl
        * @return array tableau associatif
        * @author Ahcene ALOUANE, Lounis AMMICHE.
    */
    function get_books_data_and_save_to_csv($apiUrl) : array{
        $json_data = file_get_contents($apiUrl);
        $data = json_decode($json_data, true);
        $csv_data = [];

        if (isset($data['items'])) {
            foreach ($data['items'] as $item) {
                $title = isset($item['volumeInfo']['title']) ? $item['volumeInfo']['title'] : 'Titre indisponible';
                $authors = isset($item['volumeInfo']['authors']) ? implode(', ', $item['volumeInfo']['authors']) : 'Auteur(s) indisponible(s)';
                $image = isset($item['volumeInfo']['imageLinks']['thumbnail']) ? $item['volumeInfo']['imageLinks']['thumbnail'] : 'images/none.png';
                $isbn = isset($item['volumeInfo']['industryIdentifiers'][0]['identifier']) ? $item['volumeInfo']['industryIdentifiers'][0]['identifier'] : 'ISBN indisponible';
                $id = $item['id'];

                $csv_data[] = [
                    'title' => $title,
                    'authors' => $authors,
                    'image' => $image,
                    'isbn' => $isbn,
                    'id' => $id,
                ];
            }

            $file = fopen('data/tendancesBooks.csv', 'w');
            fputcsv($file, ['title', 'authors', 'image', 'isbn', 'id']);

            foreach ($csv_data as $row) {
                fputcsv($file, $row);
            }

            fclose($file);
        }

        return $csv_data;
    }

             /**
                * La fonction read_books_data_from_csv_collection() lit les données stockées dans un fichier CSV et les renvoie sous forme de tableau associatif.
                *
                * La fonction ne prend aucun param
                * @return array tableau associatif
                * @author Ahcene ALOUANE, Lounis AMMICHE.
            */
            function read_books_data_from_csv() : array {
                $file = fopen('data/tendancesBooks.csv', 'r');
                $books_data = [];

                $header = fgetcsv($file);

                while (($row = fgetcsv($file)) !== false) {
                    $books_data[] = array_combine($header, $row);
                }

                fclose($file);

                return $books_data;
            }

            /**
                * La fonction get_books_data_and_save_to_csv_collection() récupère des données de livres à partir d'une API en ligne, les traite et les stocke dans un fichier CSV.
                *
                * La fonction ne prend aucun param
                * @return array tabelau associatif
                * @author Ahcene ALOUANE, Lounis AMMICHE.
            */
            function get_books_data_and_save_to_csv_collection($apiUrl) : array{
                $json_data = file_get_contents($apiUrl);
                $data = json_decode($json_data, true);
                $csv_data = [];

                if (isset($data['items'])) {
                    foreach ($data['items'] as $item) {
                        $title = isset($item['volumeInfo']['title']) ? $item['volumeInfo']['title'] : 'Titre indisponible';
                        $authors = isset($item['volumeInfo']['authors']) ? implode(', ', $item['volumeInfo']['authors']) : 'Auteur(s) indisponible(s)';
                        $image = isset($item['volumeInfo']['imageLinks']['thumbnail']) ? $item['volumeInfo']['imageLinks']['thumbnail'] : 'images/none.png';
                        $isbn = isset($item['volumeInfo']['industryIdentifiers'][0]['identifier']) ? $item['volumeInfo']['industryIdentifiers'][0]['identifier'] : 'ISBN indisponible';
                        $id = $item['id'];

                        $csv_data[] = [
                            'title' => $title,
                            'authors' => $authors,
                            'image' => $image,
                            'isbn' => $isbn,
                            'id' => $id,
                        ];
                    }

                    $file = fopen('data/collectionBooks.csv', 'w');
                    fputcsv($file, ['title', 'authors', 'image', 'isbn', 'id']);

                    foreach ($csv_data as $row) {
                        fputcsv($file, $row);
                    }

                    fclose($file);
                }

                return $csv_data;
            }

            /**
                * La fonction read_books_data_from_csv_collection() lit les données stockées dans un fichier CSV et les renvoie sous forme de tableau associatif.
                *
                * La fonction ne prend aucun param
                * @return array tableau associatif
                * @author Ahcene ALOUANE, Lounis AMMICHE.
            */
            function read_books_data_from_csv_collection() : array {
                $file = fopen('data/collectionBooks.csv', 'r');
                $books_data = [];

                $header = fgetcsv($file);

                while (($row = fgetcsv($file)) !== false) {
                    $books_data[] = array_combine($header, $row);
                }

                fclose($file);

                return $books_data;
            }

            
?>


