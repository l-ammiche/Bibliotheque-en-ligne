<?php


    declare (strict_types=1) ;


    /**
        * Cette fonction utilis la fonction php predefinie et aussi acceder a la langue du navigateur pour afficher la date courante avec la langue de navigateur 
        *
        * @param string $lang elle prend le mot cle fr par defaut 
        * @return string elle retourne la date avec le format qui convient a la langue de navugateur 
        * @author Ahcene ALOUANE
    */
    function get_today_date($lang = 'fr') : string {
        assert(in_array($lang, ['fr', 'en']), "La langue doit être 'fr' ou 'en'.");
        
        $months_fr = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
        $months_en = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        $days_fr = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
        $days_en = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    
        $today = new DateTime();
        $day = $today->format('d');
        $month = ($lang == 'en') ? $months_en[intval($today->format('m')) - 1] : $months_fr[intval($today->format('m')) - 1];
        $year = $today->format('Y');
        $day_of_week = ($lang == 'en') ? $days_en[intval($today->format('w'))] : $days_fr[intval($today->format('w'))];
    
        if ($lang == 'en') {
            return $day_of_week . ', ' . $month . ' ' . $day . ', ' . $year;
        } else {
            return $day_of_week . ' ' . $day . ' ' . $month . ' ' . $year;
        }
    }


    /**
      * Une fonction qui affiche le nom de navigateur utilise a l'instant
      *
      * la fonction prend aucun parametre
      * @return string le nom du navigateur 
      * @author Ahcene ALOUANE
    */
    function get_navigateur() : string {
        $navigateur = "Inconnu";
        if (isset($_SERVER['HTTP_USER_AGENT'])) {
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        if (preg_match('/Firefox/i', $user_agent)) {
            $navigateur = 'Firefox';
        } elseif (preg_match('/Chrome/i', $user_agent)) {
            $navigateur = 'Chrome';
        } elseif (preg_match('/Safari/i', $user_agent)) {
            $navigateur = 'Safari';
        } elseif (preg_match('/Opera|OPR/i', $user_agent)) {
            $navigateur = 'Opera';
        } elseif (preg_match('/Edge/i', $user_agent)) {
            $navigateur = 'Edge';
        } elseif (preg_match('/MSIE/i', $user_agent) || preg_match('/Trident/i', $user_agent)) {
            $navigateur = 'Internet Explorer';
        }
        }
        return $navigateur;
    }






?>




