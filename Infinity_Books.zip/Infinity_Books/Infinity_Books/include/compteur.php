<?php
   $file = 'data/counter.txt';

   // Vérifie si le fichier existe, sinon le crée avec un compteur initial à 0
   if (!file_exists($file)) {
      $handle = fopen($file, 'w+');
      $count = 0;
      fwrite($handle, $count);
      fclose($handle);
   } else {
      // Lit le contenu du fichier
      $handle = fopen($file, 'r');
      $count = fread($handle, filesize($file));
      fclose($handle);
   }

   // Incrémente le compteur et réécrit le fichier
   $count++;
   $handle = fopen($file, 'w');
   fwrite($handle, $count);
   fclose($handle);
?>
