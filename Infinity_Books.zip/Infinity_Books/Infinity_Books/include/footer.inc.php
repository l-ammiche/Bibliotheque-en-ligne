<?php require "./include/util.inc.php"; ?>
<?php include('compteur.php'); ?>

        <footer>
            <div class="footer-content">
              
              <div class="footer-section contact">
                <span class="titleFooter">Rejoignez-nous</span>
                <ul>
                  <li><a href="mailto:books.contacte@gmail.com" target="_blank" title="Rejoignez-nous par mail"><img src="images/gmail.png" alt="Icône logo de Gmail" /></a></li>
                  <li><a href="https://github.com/AsseineXXX" target="_blank" title="Rejoignez-nous sur Github"><img src="images/github.png" alt="Icône logo de github" /></a> </li>
                  <li><a href="https://www.linkedin.com/in/ahcene-alouane-543066254/" target="_blank" title="Rejoignez-nous sur Linkedin"><img src="images/linkedin.png" alt="Icône logo de Linkedin" /></a> </li>
                </ul> 
              </div>

              <div class="footer-section links">
                <span class="titleFooter">Autres</span>
                <ul>
                  <li>
                          <?php
                              //echo get_today_date2(substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2)); 
                              $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2); // Récupère les deux premiers caractères de la langue du serveur
                              $date = ($lang == 'fr') ? get_today_date('fr') : get_today_date('en'); // Appelle la fonction avec le paramètre correspondant à la langue 
                              echo "Date : ".$date; // Affiche la date
                          ?>
                  </li>
                  <li>
                      <?php
                              echo "Navigateur : " . get_navigateur() ;
                      ?>
                  </li>
                  <li>
                    <?php 
                          // Affiche le nombre de hits
                          echo "Vous êtes le visiteur : ".$count;
                    ?>
                  </li>
                </ul>
              </div>
    
              <div class="footer-section links">
                <span class="titleFooter">Liens utiles</span>
                <ul>
                  <li><a href="index.php" title="Lien vers la page d'acceuil du site">InfinityBooks</a></li>
                  <li><a href="bibliotheque.php" title="Lien vers ma bibliothèque">Ma bibliothèque</a></li>
                  <li><a href="auteurs.php" title="Lien vers la page des auteurs">Auteurs</a></li>
                  <li><a href="plan-site.php" title="Liens vers la page du plan du site">Plan du site</a></li>
                  <li><a href="tech.php" title="Lien vers un coin des programmeurs">Geeky side</a></li>
                  <li><a href="a-propos.php" title="Lien vers la page à propos du site">À propos</a></li>
                </ul>
              </div>
            </div>
            <div class="footer-bottom">
            <span>Tous droits réservés. Books</span>
            </div>
          </footer>
        <script>
          <![CDATA[
          document.addEventListener('DOMContentLoaded', function() {
            const addToLibraryButtons = document.querySelectorAll('.add-to-library');

            addToLibraryButtons.forEach(function(btn) {
              btn.addEventListener('click', function(event) {
                event.preventDefault();

                const bookId = this.dataset.id;

                if (!getCookie('library')) {
                  setCookie('library', JSON.stringify([bookId]), 30);
                } else {
                  const library = JSON.parse(getCookie('library'));
                  
                  if (!library.includes(bookId)) {
                    library.push(bookId);
                    setCookie('library', JSON.stringify(library), 30);
                  }
                }

                window.location.href = 'bibliotheque.php';
              });
            });
          });

          function setCookie(name, value, days) {
            const date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            const expires = 'expires=' + date.toUTCString();
            document.cookie = name + '=' + value + ';' + expires + ';path=/';
          }

          function getCookie(name) {
            const cookieName = name + '=';
            const cookies = document.cookie.split(';');
            
              for (let i = 0; i < cookies.length; i++) {
                let cookie = cookies[i];
                while (cookie.charAt(0) === ' ') {
                  cookie = cookie.substring(1);
                }
                if (cookie.indexOf(cookieName) === 0) {
                  return cookie.substring(cookieName.length, cookie.length);
                }
              
            }
            return '';
          }
          ]]>
        </script>
  </body>
</html>