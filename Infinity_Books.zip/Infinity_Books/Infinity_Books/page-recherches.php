<?php 
session_start();

if (isset($_GET['add'])) {
    $bookToAdd = $_GET['add'];
    $bookInfo = array(
        "id" => $_GET['id'],
        "title" => $_GET['title'],
        "authors" => $_GET['authors'],
        "image" => $_GET['image'],
        "isbn" => $_GET['isbn'],
    );
    if (!isset($_COOKIE["library"])) {
        $library = array();
    } else {
        $library = json_decode($_COOKIE["library"], true);
    }
    $library[$bookToAdd] = $bookInfo;
    setcookie("library", json_encode($library), time() + (30 * 24 * 60 * 60), "/"); // Durée d'un mois
    echo "<script>window.history.back();</script>";
    exit;
}

if (isset($_GET['remove'])) {
  $bookToRemove = $_GET['remove'];
  if (isset($_COOKIE["library"]) && array_key_exists($bookToRemove, json_decode($_COOKIE["library"], true))) {
      $library = json_decode($_COOKIE["library"], true);
      unset($library[$bookToRemove]);
      setcookie("library", json_encode($library), time() + (30 * 24 * 60 * 60), "/"); // Durée d'un mois
  }
  echo "<script>window.history.back();</script>";
  exit;
}
?>
<?php

// Vérifie si une recherche a été effectuée
if(isset($_GET['search']) && strlen(trim($_GET['search'])) > 0) {
    // Récupère la valeur de la recherche
    $search = $_GET['search'];
    
    // Récupère l'historique des recherches à partir du cookie, s'il existe
    $search_history = isset($_COOKIE['search_history']) ? unserialize($_COOKIE['search_history']) : array();
    
    // Ajoute la nouvelle recherche à l'historique
    array_unshift($search_history, $search);
    
    // Limite l'historique à 6 éléments
    $search_history = array_slice($search_history, 0, 6);
    
    // Enregistre l'historique des recherches dans le cookie
    setcookie('search_history', serialize($search_history), time()+3600);
}

// Récupère l'historique des recherches à partir du cookie, s'il existe
$search_history = isset($_COOKIE['search_history']) ? unserialize($_COOKIE['search_history']) : array();

?>
<?php
if(isset($_GET['search']) && !empty($_GET['search'])) {
  // Ouverture du fichier de statistiques en mode lecture-écriture
  $file = fopen("data/searchs.txt", "r+");
  // Lecture de la valeur actuelle
  $count = intval(fgets($file));
  // Incrémentation du compteur
  $count++;
  // Positionnement au début du fichier pour réécrire la valeur mise à jour
  rewind($file);
  // Écriture de la nouvelle valeur
  fwrite($file, $count);
  // Fermeture du fichier
  fclose($file);
}
?>
<?php
    $style = '

        <style>

          /* Style pour le formulaire de recherche */
          .search-container {
            display: flex;
    flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
            align-items: center;
            padding: 20px;
            border-radius: 10px;
            }
            
            input[type="text"] {
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            width: 300px;
            margin-right: 10px;
            background-color: #cecece;
            }
            
            input[type="text"]:focus {
            outline: none;
            background-color: #cecece;
            box-shadow: 0 0 3px #ccc;
            }
            
            select {
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            margin-right: 10px;
            background-color: #cecece;
            }
            
            button[type="submit"] {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
            }
            
            /* Style pour licône de loupe */
            .icon {
            position: relative;
            display: inline-block;
            width: 20px;
            height: 20px;
            margin-right: 5px;
            }
            
            .icon:before {
            content: "\f002";
            font-family: FontAwesome;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            }
            
            /* Style pour limage à côté du champ de recherche */
            .image {
            display: inline-block;
            width: 50px;
            height: 50px;
            margin-left: 10px;
            background-image: url("chemin/vers/image.jpg");
            background-size: cover;
            background-position: center;
            border-radius: 50%;
            }


            
                
            
          

          
          button.show-more {
            display: block;
            margin-top: 10px;
            padding: 5px 10px;
            background-color: #282828;
            border: 1px solid #ccc;
            border-radius: 4px;
            cursor: pointer;
            color : white;
        }
        
        button.show-more:hover{
          filter: brightness(1.2);
          transform: scale(1.05);
        }



       
        </style>  


    ';

    $title="Page de recherche" ;
    $description="Cette page est dédiée pour effectuer des recherches des livres et afficher les résultats de chaque recherche, ainsi que pour afficher une collection du jour proposé au visiteurs et le dernier livre consulté." ; 
    require "./include/functions.inc.php";
    require "./include/header.inc.php";
?>
        <main>


          <aside>
              <ul class="switch-mode">
              <li>
                  <a href="?style=styles" class="day-mode active" title="Activer le mode nuit">
                  <img src="images/night.png" alt="Mode Nuit" />
                  </a>
              </li>
              <li>
                  <a href="?style=style_clair" class="night-mode" title="activer le mode jour">
                  <img src="images/mode-jour.png" alt="Mode Jour" />
                  </a>
              </li>
              <li>
                  <a href="#" class="haut" title="Revenir en haut de page">
                  <img src="images/haut.png" alt="flèche vers le haut" />
                  </a>
              </li>
              </ul>
          </aside>

            <h1>Recherche de livre</h1>

    <section>

        <h2>Recherche</h2>

        <div class="search-container">
          <form action="page-recherches.php" method="get">
              <input type="text" placeholder="Livre, auteur, ISBN ..." name="search" value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>" />
              <select name="search_option">
                  <option value="name">Recherche par nom du livre</option>
                  <option value="auteur">Recherche par Auteur</option>
                  <option value="isbn">Recherche par ISBN</option>
              </select>
              <?php if(!empty($search_history)): ?>
              <select name="search_history" onchange="this.form.search.value=this.value; this.form.submit();">
                  <option value="">Recherches récentes</option>
                  <?php foreach($search_history as $search): ?>
                  <option value="<?php echo $search; ?>"><?php echo $search; ?></option>
                  <?php endforeach; ?>
              </select>
              <?php endif; ?>
              <button type="submit" title="Rechercher">Rechercher</button>
          </form>
      </div>

            <?php include('search.php'); ?>               
        
    </section> 

              <?php
                // Vérification si le cookie existe
                if (isset($_COOKIE['book_info'])) {
                  $bookInfoC = json_decode($_COOKIE['book_info'], true);
                  $title = $bookInfoC['title'];
                  $authors = $bookInfoC['authors'];
                  $isbn = $bookInfoC['isbn'];
                  $image = $bookInfoC['image'];
                  $id = $bookInfoC['id'];
                
                  $bookInLibrary = false;
                  if (isset($_COOKIE['library'])) {
                    $library = json_decode($_COOKIE['library'], true);
                    $bookInLibrary = array_key_exists($id, $library);
                  }

              ?>
              <section>
                <h2>Mon dernier livre consulté</h2>
                  <?php $image= str_replace('&', '&amp;', $image); ?>
                <div class="book-container">
                  <article class="book">
                  <figure class="book-image">
                    <img src="<?= $image ?>" alt="alt='Image de couverture de livre." />
                    <figcaption></figcaption>
                  </figure>
                  <div class="book-details">
                    <h3><?= $title ?></h3>
                    <span><strong>Par</strong> <?= $authors ?></span>
                    <span><strong>ISBN: </strong><?= $isbn ?></span>
                  <?php echo "<a href='details.php?id=$id' class='show-more' title='Afficher plus d infos sur ce livre'>Afficher plus</a> \n"; ?>
                  
                <?php
                
                  $bookInLibrary = false;
                  if (isset($_COOKIE['library'])) {
                    $library = json_decode($_COOKIE['library'], true);
                    $bookInLibrary = array_key_exists($id, $library);
                  }

                  if ($bookInLibrary) {
                    echo "<a href='?remove=$id' class='show-more' title='Retirer ce livre de la bibliothèque'>Retirer de ma bibliothèque</a>\n";
                  } else {
                    echo "<a href='?add=$id&amp;title=" . urlencode($title) . "&amp;authors=" . urlencode($authors) . "&amp;image=" . urlencode($image) . "&amp;isbn=" . urlencode($isbn) . "&amp;id=" . urlencode($id) . "' class='show-more' title='Ajouter ce livre à votre collection'>Ajouter à ma bibliothèque</a>\n";                        
                  }
              ?>

                </div>
              </article>
              </div>
                          
                  <?php
                    
                  echo "</section>\n";
                  }
                ?>

                
                <?php 
              
              if(!isset($_GET['search']) || empty($search)){
                
                
                $apiKey = 'AIzaSyDLL3CRwM2_DF-bRow-WYv8yYzBEZQuBzQ';
                $apiUrl = 'https://www.googleapis.com/books/v1/volumes?q=*&maxResults=10&printType=books&key=' . $apiKey;
                $csv_file = 'data/collectionBooks.csv';
                $update_interval =  24 * 60 * 60; // 1 days
                
                if (!file_exists($csv_file) || (time() - filemtime($csv_file) > $update_interval)) {
                  $books_data = get_books_data_and_save_to_csv_collection($apiUrl);
                } else {
                  $books_data = read_books_data_from_csv_collection();
                }
                
                echo "<section>\n";
                  echo "<h2>Collection du jour</h2> \n";
                  if (!empty($books_data)) {
                    echo "<div class='book-container'>\n";
                      foreach ($books_data as $book) {
                          $title = $book['title'];
                          $authors = $book['authors'];
                          $image = $book['image'];
                          $isbn = $book['isbn'];
                          $id = $book['id'];
                          ?>
                          <?php $image= str_replace('&', '&amp;', $image); ?>
                            <article class="book">
                                <figure class="book-image">
                                    <img src="<?= $image ?>" alt="alt='Image de couverture de livre " />
                                    <figcaption></figcaption>
                                </figure>
                                <div class="book-details">
                                    <h3><?= $title ?></h3>
                                    <span><strong>Par</strong> <?= $authors ?></span>
                                    <span><strong>ISBN: </strong><?= $isbn ?></span>
                                    <?php echo "<a href='details.php?id=$id' class='show-more' title='Afficher plus d infos sur ce livre'>Afficher plus</a> \n"; ?>
                                    
                                    
                                    <?php 
                                    
                                      $bookInLibrary = false;
                                      if (isset($_COOKIE['library'])) {
                                          $library = json_decode($_COOKIE['library'], true);
                                          $bookInLibrary = array_key_exists($id, $library);
                                      }

                                      if ($bookInLibrary) {
                                          echo "<a href='?remove=$id' class='show-more' title='Retirer ce livre de ma bibliothèque'>Retirer de ma bibliothèque</a>\n";
                                      } else {
                                        echo "<a href='?add=$id&amp;title=" . urlencode($title) . "&amp;authors=" . urlencode($authors) . "&amp;image=" . urlencode($image) . "&amp;isbn=" . urlencode($isbn) . "&amp;id=" . urlencode($id) . "' class='show-more' title='Ajouter ce livre à votre collection'>Ajouter à ma bibliothèque</a>\n";                        
                                      }

                                    ?>

                                </div>
                            </article>
                    <?php
                        }
                        echo '</div>';
                    } else {
                        echo "<span>Une erreur s'est produite lors de la récupération des données des livres.</span>";
                    }
                    echo "</section>\n";
                }
              
              ?>

            
        
      </main>

<?php
    require "./include/footer.inc.php"; 
?>