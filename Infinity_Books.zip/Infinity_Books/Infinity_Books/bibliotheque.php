<?php
   if (isset($_GET['remove'])) {
    $bookToRemove = $_GET['remove'];
    if (isset($_COOKIE["library"]) && array_key_exists($bookToRemove, json_decode($_COOKIE["library"], true))) {
        $library = json_decode($_COOKIE["library"], true);
        unset($library[$bookToRemove]);
        setcookie("library", json_encode($library), time() + (30 * 24 * 60 * 60), "/"); // Durée d'un mois
    }
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
  } 
?>
<?php 
session_start();

$style = '

<style>
.message {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 5vh;
  }

  
.book-container {
    margin-top: 50px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  
  .book {
    width: 48%;
    margin-bottom: 50px;
    border: 2px solid rgb(0, 0, 0);
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0,0,0,0.1);
    display: flex;
    flex-direction: row;
  }
  
  .book-image {
    width: 30%;
    padding: 10px;
  }
  
  .book-image img {
    width: 100%;
    border-radius: 5px;
  }
  
  .book-details {
    width: 70%;
    padding: 10px;
  }
  
  .book h2 {
    font-size: 18px;
    margin-bottom: 10px;
  }
  
  .book span {
    font-size: 15px;
    line-height: 1.5;
    margin-bottom: 10px;
    display: block;
    margin-bottom: 10px;
    text-align: left;
  }
  
  .book h3{
  
    background-color: #222222;
    color: white;
    border-radius: 20px;
  }

</style>

';
$title="Ma bibliothèque";
$description="Cette page reprèsente la collection des livres préférés du visiteur, elle fonctionne par mécanisme des cookies, elle sauvegarde pendant tout un mois ses livres préférés en proposant l'option de les retirer de la bibliothèque s'il le souhaite.";
require "./include/header.inc.php";

if (isset($_COOKIE["library"])) {
    $library = json_decode($_COOKIE["library"], true);

    if (count($library) > 0) {
        
        echo "<main>\n";

        echo "<aside>\n";
            echo "<ul class='switch-mode'>\n";
                echo "<li>\n";
                    echo '<a href="?style=styles" class="day-mode active" title="Activer le mode nuit">'."\n";
                    echo '<img src="images/night.png" alt="Mode Nuit" />'."\n";
                    echo"</a>\n";
                echo "</li>\n";
                echo "<li>\n";
                    echo '<a href="?style=style_clair" class="night-mode" title="activer le mode jour">';
                    echo '<img src="images/mode-jour.png" alt="Mode Jour" />';
                    echo "</a>\n";
                echo "</li>\n";
                echo "<li>\n";
                    echo '<a href="#" class="haut" title="Revenir en haut de page">';
                    echo '<img src="images/haut.png" alt="flèche vers le haut" />';
                    echo "</a>\n";
                echo "</li>\n";
            echo "</ul>\n";
        echo "</aside>\n";

        echo "<h1>Ma collection de livres</h1>\n";

        $booksPerPage = 10;
        $totalBooks = count($library);
        $totalPages = ceil($totalBooks / $booksPerPage);

        if (isset($_GET['page'])) {
            $currentPage = intval($_GET['page']);
        } else {
            $currentPage = 1;
        }

        $startIndex = ($currentPage - 1) * $booksPerPage;
        $endIndex = min($startIndex + $booksPerPage, $totalBooks);


        echo "<div class='book-container'>\n";

        foreach ($library as $book) {
            $id = $book['id'];
            $title = $book['title'];
            $authors = $book['authors'];
            $image = $book['image'];
            $isbn = $book['isbn'];

            echo "<section class='book'> \n";
            if ($image != '') {
                echo "<figure class='book-image'> \n";
                echo "<img src='$image' alt='Image de couverture de livre'> \n";
                echo "<figcaption></figcaption> \n";
                echo "</figure> \n";
            }
            echo "<div class='book-details'> \n";
            echo "<h2>$title</h2> \n";
            echo "<span><strong>Par</strong> $authors</span> \n";
            echo "<span><strong>ISBN: </strong> $isbn </span>\n";
            echo "<a href='details.php?id=$id' class='show-more' title='Afficher plus d infos sur ce livre'>Afficher plus</a>\n";
            echo "<a href='?remove=$id' class='show-more' title='Retirer ce livre dans ma bibliothèque'>Retirer de ma bibliothèque</a>\n";
            echo "</div> \n";
            echo "</section> \n";
        }
        echo "</main>\n";
        echo "</div>";

    } else {
        echo "<main>\n";

        echo "<aside>\n";
        echo "<ul class='switch-mode'>\n";
            echo "<li>\n";
                echo '<a href="?style=styles" class="day-mode active" title="Activer le mode nuit">'."\n";
                echo '<img src="images/night.png" alt="Mode Nuit" />'."\n";
                echo"</a>\n";
            echo "</li>\n";
            echo "<li>\n";
                echo '<a href="?style=style_clair" class="night-mode" title="activer le mode jour">';
                echo '<img src="images/mode-jour.png" alt="Mode Jour" />';
                echo "</a>\n";
            echo "</li>\n";
            echo "<li>\n";
                echo '<a href="#" class="haut" title="Revenir en haut de page">';
                echo '<img src="images/haut.png" alt="flèche vers le haut" />';
                echo "</a>\n";
            echo "</li>\n";
        echo "</ul>\n";
    echo "</aside>\n";

        // Si la bibliothèque est vide, afficher une image par défaut
        echo "<h1>Ma collection de livres</h1>\n";
        echo "<div class='empty-library'>\n";
        echo "<figure> \n";
        echo "<img src='images/error.png' alt='Ma bibliothèque est vide' width='550'/> \n";
        echo "<figcaption></figcaption>";
        echo "</figure> \n";        
        echo "<span class='message'>Votre bibliothèque est vide pour le moment, vous pouvez créer votre propre collection en ajoutant des livres.</span>\n";
        echo "<a href='page-recherches.php' title='Aller vers la page de la recherche' class='message'>Retour à la page de recherche</a>\n";
        echo "</div>\n";
    
        echo "</main>\n";
    }
} else {
    echo "<main>\n";

    echo "<aside>\n";
    echo "<ul class='switch-mode'>\n";
        echo "<li>\n";
            echo '<a href="?style=styles" class="day-mode active" title="Activer le mode nuit">'."\n";
            echo '<img src="images/night.png" alt="Mode Nuit" />'."\n";
            echo"</a>\n";
        echo "</li>\n";
        echo "<li>\n";
            echo '<a href="?style=style_clair" class="night-mode" title="activer le mode jour">';
            echo '<img src="images/mode-jour.png" alt="Mode Jour" />';
            echo "</a>\n";
        echo "</li>\n";
        echo "<li>\n";
            echo '<a href="#haut" class="haut" title="Revenir en haut de page">';
            echo '<img src="images/haut.png" alt="flèche vers le haut" />';
            echo "</a>\n";
        echo "</li>\n";
    echo "</ul>\n";
echo "</aside>\n";

    // Si la bibliothèque est vide, afficher une image par défaut
    echo "<h1>Ma collection de livres</h1>\n";
        echo "<div class='empty-library'>\n";
        echo "<figure> \n";
        echo "<img src='images/error.png' alt='Ma bibliothèque est vide' width='550'/> \n";
        echo "<figcaption></figcaption>";
        echo "</figure> \n";        
        echo "<span class='message'>Votre bibliothèque est vide pour le moment, vous pouvez créer votre propre collection en ajoutant des livres.</span>\n";
        echo "<a href='page-recherches.php' title='Aller vers la page de la recherche' class='message'>Retour à la page de recherche</a>\n";
        echo "</div>\n";
    
        echo "</main>\n";
}
?>
<?php
    require "./include/footer.inc.php"; 
?>