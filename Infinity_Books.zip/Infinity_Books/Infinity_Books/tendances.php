<?php 
session_start();

if (isset($_GET['add'])) {
    $bookToAdd = $_GET['add'];
    $bookInfo = array(
        "id" => $_GET['id'],
        "title" => $_GET['title'],
        "authors" => $_GET['authors'],
        "image" => $_GET['image'],
        "isbn" => $_GET['isbn'],
    );
    if (!isset($_COOKIE["library"])) {
        $library = array();
    } else {
        $library = json_decode($_COOKIE["library"], true);
    }
    $library[$bookToAdd] = $bookInfo;
    setcookie("library", json_encode($library), time() + (30 * 24 * 60 * 60), "/"); // Durée d'un mois
    echo "<script>window.history.back();</script>";
    exit;
}

if (isset($_GET['remove'])) {
  $bookToRemove = $_GET['remove'];
  if (isset($_COOKIE["library"]) && array_key_exists($bookToRemove, json_decode($_COOKIE["library"], true))) {
      $library = json_decode($_COOKIE["library"], true);
      unset($library[$bookToRemove]);
      setcookie("library", json_encode($library), time() + (30 * 24 * 60 * 60), "/"); // Durée d'un mois
  }
  echo "<script>window.history.back();</script>";
  exit;
}
?>
<?php
    $style = '
    
    <style>

    .book-container {
        margin-top: 50px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
      }
      
      .book {
        width: 48%;
        margin-bottom: 50px;
        border: 2px solid rgb(0, 0, 0);
        border-radius: 5px;
        box-shadow: 0 0 5px rgba(0,0,0,0.1);
        display: flex;
        flex-direction: row;
      }
      
      .book-image {
        width: 30%;
        padding: 10px;
      }
      
      .book-image img {
        width: 100%;
        border-radius: 5px;
      }
      
      .book-details {
        width: 70%;
        padding: 10px;
      }
      
      .book h2 {
        font-size: 18px;
        margin-bottom: 10px;
      }
      
      .book span {
        font-size: 15px;
        line-height: 1.5;
        margin-bottom: 10px;
        display: block;
        margin-bottom: 10px;
        text-align: left;
      }
      
      .book h3{
      
        background-color: #222222;
        color: white;
        border-radius: 20px;
      }

</style>
    
    ';
    $title="Les livres tendnce" ;
    $description="Cette page founit aux visiteurs les 10 livres tendace actuelle dans le monde" ; 
    require "./include/functions.inc.php";
    require "./include/header.inc.php";
?>

        <main>
            <aside>
                <ul class="switch-mode">
                <li>
                    <a href="?style=styles" class="day-mode active" title="Activer le mode nuit">
                    <img src="images/night.png" alt="Mode Nuit" />
                    </a>
                </li>
                <li>
                    <a href="?style=style_clair" class="night-mode" title="activer le mode jour">
                    <img src="images/mode-jour.png" alt="Mode Jour" />
                    </a>
                </li>
                <li>
                    <a href="#" class="haut" title="Revenir en haut de page">
                    <img src="images/haut.png" alt="flèche vers le haut" />
                    </a>
                </li>
                </ul>
            </aside>

            <h1>Livres tendances</h1>
    
            <?php

            $apiKey = 'AIzaSyDLL3CRwM2_DF-bRow-WYv8yYzBEZQuBzQ';
            $apiUrl = "https://www.googleapis.com/books/v1/volumes?q=fiction&orderBy=relevance&maxResults=10&key=$apiKey";
            $csv_file = 'data/tendancesBooks.csv';
            $update_interval = 7 * 24 * 60 * 60; // 7 days

            if (!file_exists($csv_file) || (time() - filemtime($csv_file) > $update_interval)) {
                $books_data = get_books_data_and_save_to_csv($apiUrl);
            } else {
                $books_data = read_books_data_from_csv();
            }

            if (!empty($books_data)) {
                echo "<div class='book-container'>\n";
                foreach ($books_data as $book) {
                    $title = $book['title'];
                    $authors = $book['authors'];
                    $image = $book['image'];
                    $isbn = $book['isbn'];
                    $id = $book['id'];

                    

                    //échapper les caractères "&" dans les URLs des images
                    $image= str_replace('&', '&amp;', $image);


                    echo "<section class='book'> \n";
                    if ($image != '') {
                        echo "<figure class='book-image'> \n";
                        echo "<img src='$image' alt='Image de couverture de livre.'/> \n";
                        echo "<figcaption></figcaption>";
                        echo "</figure> \n";
                    }
                    echo "<div class='book-details'> \n";
                    echo "<h2>$title</h2> \n";
                    echo "<span><strong>Par</strong> $authors</span> \n";
                    echo "<span><strong>ISBN: </strong> $isbn </span>\n";
                    echo "<a href='details.php?id=$id' class='show-more' title='Afficher plus d infos sur ce livre'>Afficher plus</a> \n";
    
    
                    $bookInLibrary = false;
                    if (isset($_COOKIE['library'])) {
                        $library = json_decode($_COOKIE['library'], true);
                        $bookInLibrary = array_key_exists($id, $library);
                    }
    
                    if ($bookInLibrary) {
                        echo "<a href='?remove=$id' class='show-more' title='Supprimer le livre de votre collection'>Retirer de ma bibliothèque</a>\n";
                    } else {
                        echo "<a href='?add=$id&amp;title=" . urlencode($title) . "&amp;authors=" . urlencode($authors) . "&amp;image=" . urlencode($image) . "&amp;isbn=" . urlencode($isbn) . "&amp;id=" . urlencode($id) . "' class='show-more' title='Ajouter ce livre à votre collection'>Ajouter à ma bibliothèque</a>\n";                        
                    }
    
                    echo "</div> \n";
                    echo "</section> \n";
                       
                    ?>
                   

        <?php
    }
    echo "</div> \n"; 
} else {
    echo "<span>Une erreur s'est produite lors de la récupération des données des livres tendances.</span>\n";
}
?>
        </main>

<?php
    require "./include/footer.inc.php"; 
?>