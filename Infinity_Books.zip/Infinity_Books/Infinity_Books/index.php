<?php
    require "./include/functions.inc.php";
?>
<?php
if (isset($_GET['style']) && ($_GET['style'] == 'style_clair' || $_GET['style'] == 'styles')) {
  // Crée un cookie pour enregistrer la préférence de l'utilisateur
  setcookie('style', $_GET['style'], time() + (86400 * 30), '/');
  header('Location: '.$_SERVER['PHP_SELF']);
  exit;
}
// Vérifie si l'utilisateur a déjà choisi un mode de couleur
if (isset($_COOKIE['style'])) {
  // Si oui, inclure le fichier CSS correspondant
  if ($_COOKIE['style'] == 'style_clair') {
    $stylesheet = 'style_clair.css';
  } else {
    $stylesheet = 'styles.css';
  }
} else {
  // Si non, utiliser le mode clair par défaut
  $stylesheet = 'styles.css';
}
if (isset($id, $title, $authors, $description, $image, $isbn, $publishedDate, $publisher)) {
  $row = array($id, $title, $authors, $description, $image, $isbn, $publishedDate, $publisher);
  $file = fopen('books.csv', 'a');
  fputcsv($file, $row);
  fclose($file);
}
?>
<?php
    $style = '
        <style>
        
        .container {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            margin: 10px;
          }
          
          .description {
            flex: 1;
            margin-right: 10px;
            max-width: 50%;
            word-wrap: break-word;

          }
          
          .image {
            flex: 1;
            max-width: 50%;
          }
          
          .image img {
            max-width: 100%;
            height: auto;
          }

        </style>
        

    ';
    $title=" Infinity Books " ;
    $description="Il s'agit bien de la page d'acceuil du site Infinity Books " ; 
    require "./include/header.inc.php";
    
?>



<main>
        <aside>
            <ul class="switch-mode">
                <li>
                    <a href="?style=styles" class="day-mode active" title="Activer le mode nuit">
                    <img src="images/night.png" alt="Mode Nuit" />
                    </a>
                </li>
                <li>
                    <a href="?style=style_clair" class="night-mode" title="activer le mode jour">
                    <img src="images/mode-jour.png" alt="Mode Jour" />
                    </a>
                </li>
                <li>
                    <a href="#" class="haut" title="Revenir en haut de page">
                    <img src="images/haut.png" alt="flèche vers le haut" />
                    </a>
                </li>
            </ul>
        </aside>
        
    <h1>Infinity Books</h1>
    
    <section class="container">
        <div class="description">
            <h2>Description</h2> 
            <p>La lecture est une activité importante pour de nombreuses personnes, qu'il s'agisse de se divertir, d'apprendre ou de se détendre. Cependant, il peut être difficile de chercher des livres intéressants et pertinents dans la masse d'informations disponibles en ligne ou même dans des bibliothèques. Notre projet vise à créer un site web orienté pour la lecture, qui permettra aux utilisateurs de chercher facilement leurs besoins dans ce monde de livres . Le site proposera également des fonctionnalités de recommandation personnalisées, en fonction des préférences de lecture de chaque utilisateur. L'objectif est de faciliter le maximum possible la recherche des informations sur les livres. </p>
        </div>
        <div class="image">
            <figure>
            <img src="<?php echo 'imagesAlea/' . rand(1, 8) . '.png'; ?>" alt="Image"/>
            <figcaption></figcaption>
            </figure>
        </div>
    </section>


</main>

<?php
    require "./include/footer.inc.php"; 
?>