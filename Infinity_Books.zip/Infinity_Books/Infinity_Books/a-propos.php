<?php
if (isset($_GET['style']) && ($_GET['style'] == 'style_clair' || $_GET['style'] == 'styles')) {
  // Crée un cookie pour enregistrer la préférence de l'utilisateur
  setcookie('style', $_GET['style'], time() + (86400 * 30), '/');
  header('Location: '.$_SERVER['PHP_SELF']);
  exit;
}
// Vérifie si l'utilisateur a déjà choisi un mode de couleur
if (isset($_COOKIE['style'])) {
  // Si oui, inclure le fichier CSS correspondant
  if ($_COOKIE['style'] == 'style_clair') {
    $stylesheet = 'style_clair.css';
  } else {
    $stylesheet = 'styles.css';
  }
} else {
  // Si non, utiliser le mode clair par défaut
  $stylesheet = 'styles.css';
}
?>
<?php
    $style = '';
    $title="À propos" ;
    $description="Cette page offre un ensemble d'informations concernant ce site que le visiteur voudrais savoir." ; 
    require "./include/header.inc.php";
?>

        <main>
            <aside>
                <ul class="switch-mode">
                <li>
                    <a href="?style=styles" class="day-mode active" title="Activer le mode nuit">
                    <img src="images/night.png" alt="Mode Nuit" />
                    </a>
                </li>
                <li>
                    <a href="?style=style_clair" class="night-mode" title="activer le mode jour">
                    <img src="images/mode-jour.png" alt="Mode Jour" />
                    </a>
                </li>
                <li>
                    <a href="#" class="haut" title="Revenir en haut de page">
                    <img src="images/haut.png" alt="flèche vers le haut" />
                    </a>
                </li>
                </ul>
            </aside>
            <h1>À propos du Infinity Books</h1>

            <section>
                <h2>Qui somme nous ?</h2>
                <p>Bonjour et bienvenue sur <strong>Infinity Books</strong> ! Nous sommes <strong>Ahcene ALOUANE</strong> et <strong>Lounis AMMICHE</strong>, deux étudiants en Licence 2 informatique à l'université de CY Cergy Paris Université, années 2022-2023.</p>
                <span>Retrouvez plus d'informations sur nous sur notre <a href="auteurs.php" title="Liens vers la page des auteurs">page auteurs</a>.</span>
            </section>

            <section>
                <h2>Pourquoi Infinity Books ?</h2>
                <p><strong>Infinity Books</strong> a été conçu pour un projet en deuxieme années de licence informatique, à l'université de Cergy-Pontoise.</p>
                <p><strong>Infinity Books</strong> a été créé également pour offrir aux passionné(e)s de la lecture une plateforme assez complète et facilement accessible pour trouver des informations sur les livres. Nous avons choisi d'utiliser l'API de Google Books pour créer une base de données détaillée de livres, permettant ainsi aux visiteurs de rechercher des livres par titre, auteur ou ISBN.</p>
                <p>Notre site offre également une collection de livres proposés, mis à jour quotidiennement, ainsi que les tendances de lecture pour aider les visiteurs à découvrir de nouveaux livres passionnants. En plus de cela, <strong>Infinity Books</strong> propose une fonctionnalité de bibliothèque personnalisée, permettant aux visiteurs de garder une collection de leurs livres préférés et de marquer ceux qu'ils ont déjà lus</p>
                <p>Nous avons voulu créer une plateforme qui soit simple et intuitive à utiliser, offrant une expérience de navigation agréable pour les visiteurs. </p>
                <p>Nous sommes déterminés à continuer à améliorer Infinity Books pour offrir la meilleure expérience possible à nos visiteurs. Nous espérons que vous apprécierez votre visite sur notre site et que vous reviendrez souvent pour découvrir de nouveaux livres et fonctionnalités passionnants</p>
            </section>
        </main>


<?php
    require "./include/footer.inc.php"; 
?>