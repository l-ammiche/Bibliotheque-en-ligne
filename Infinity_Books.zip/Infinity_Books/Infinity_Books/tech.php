<?php
if (isset($_GET['style']) && ($_GET['style'] == 'style_clair' || $_GET['style'] == 'styles')) {
  // Crée un cookie pour enregistrer la préférence de l'utilisateur
  setcookie('style', $_GET['style'], time() + (86400 * 30), '/');
  header('Location: '.$_SERVER['PHP_SELF']);
  exit;
}
// Vérifie si l'utilisateur a déjà choisi un mode de couleur
if (isset($_COOKIE['style'])) {
  // Si oui, inclure le fichier CSS correspondant
  if ($_COOKIE['style'] == 'style_clair') {
    $stylesheet = 'style_clair.css';
  } else {
    $stylesheet = 'styles.css';
  }
} else {
  // Si non, utiliser le mode clair par défaut
  $stylesheet = 'styles.css';
}
?>
<?php
    $style = '
    <style>
    ul {
        list-style: none;
    }

    </style>';
    $title="Coin des programmeurs" ;
    $description="Cette page n'est pas forcément liée au reste du site Infinity Books, en revanche, elle s'agit d'un coin rédigé par les l'équipe du projet, ce dernier founit l'image du jour fournie par l'API NASA APOD, et affiche pour le visiteur quelques informations qu'ils lui concernent. " ; 
    require "./include/header.inc.php";
?>
<?php

    //C'est la cle que j'ai genere sur le site de la NASA
    $api_key = 'y9v7MJRMAALCfqdI7iian93F1120J7p6f7QDM5PX';

    //$date est une variable initialisee souvent par la valeur retournee par la fonction date() predefenie de PHP
    $date = date('Y-m-d');


    //Pour afficher une date qu'on veut il foudra juste remplacer le champ de la date ceci par ceci comme exeple '&date=2023-03-17';
    //Cette ligne definit l'URL de l'API que nous allons appeler pour obtenir l'image/video.
    //La variable $url contient l'URL de l'API ainsi que les paramètres de requête nécessaires pour accéder aux données de la NASA.
    //Les paramètres de requête sont la clé d'API et la date
    $url = 'https://api.nasa.gov/planetary/apod?api_key=' . $api_key . '&date=' . $date;

    //Cette ligne utilise la fonction file_get_contents() pour récupérer les données JSON de l'API en utilisant l'URL définie précédemment.
    $json_data = file_get_contents($url);

    //Cette ligne utilise la fonction json_decode() pour convertir les données JSON en un tableau PHP. Le deuxième argument true est utilisé pour retourner un tableau associatif plutôt qu'un objet.
    $data = json_decode($json_data, true);
    
?>
<?php

    //Cette ligne définit une variable $xml_url contenant l'URL de l'API de géolocalisation geoplugin.net avec le paramètre de requête ip qui est défini comme l'adresse IP de l'utilisateur ($_SERVER['REMOTE_ADDR']).
    //Cela signifie que l'API de géolocalisation utilisera l'adresse IP de l'utilisateur pour déterminer sa position géographique.
    $xml_url = 'http://www.geoplugin.net/xml.gp?ip=' . $_SERVER['REMOTE_ADDR'];

    //Cette ligne utilise la fonction file_get_contents() pour récupérer les données XML de l'API en utilisant l'URL définie précédemment.
    $xml_data = file_get_contents($xml_url);

    //Cette ligne utilise la fonction simplexml_load_string() pour convertir les données XML en un objet simpleXML qui peut être facilement parcouru en utilisant les propriétés et méthodes de cet objet. Cela permet d'accéder facilement aux informations de géolocalisation de l'utilisateur telles que la ville, le pays, la latitude et la longitude.
    $xml = simplexml_load_string($xml_data);

?>

    <main>

        <h1>Coin des Programmeurs</h1>

        <aside>
                <ul class="switch-mode">
                <li>
                    <a href="?style=styles" class="day-mode active" title="Activer le mode nuit">
                    <img src="images/night.png" alt="Mode Nuit" />
                    </a>
                </li>
                <li>
                    <a href="?style=style_clair" class="night-mode" title="activer le mode jour">
                    <img src="images/mode-jour.png" alt="Mode Jour" />
                    </a>
                </li>
                <li>
                    <a href="#" class="haut" title="Revenir en haut de page">
                    <img src="images/haut.png" alt="flèche vers le haut" />
                    </a>
                </li>
                </ul>
            </aside>

        <section>

            <h2>Image ou vidéo du jour - API NASA APOD</h2>

            <?php if ($data["media_type"] == "image") { ?>
                <figure>
                    <img src="<?php echo $data['url']; ?>" alt="Image ou vidéo du jour - API NASA APOD" width="600" />
                    <figcaption>Image du jour - API NASA APOD</figcaption>
                </figure>
            <?php } elseif ($data["media_type"] == "video") { ?>
                <iframe width="560" height="315" src="<?php echo $data['url']; ?>" title="Vidéo du jour - NASA APOD"></iframe>
            <?php } else { ?>
                <span>Type de fichier non pris en charge.</span>
            <?php } ?>

        </section>

        <section>

            <h2>Ma position géographique et d'autres informations</h2>

            <?php
                
                echo "<ul>";

                    echo "<li><strong>Votre adresse IP :</strong>".$_SERVER['REMOTE_ADDR']."</li>" ;

                    echo "<li><strong>Votre ville :</strong>".$xml->geoplugin_city ."</li>";
                    echo "<li><strong>Votre pays :</strong>".$xml->geoplugin_countryName."</li>";
                    echo "<li><strong>Votre région :</strong>".$xml->geoplugin_region ."</li>";
                    echo "<li><strong>Votre code de la région :</strong>".$xml->geoplugin_regionCode ."</li>";
                    echo "<li><strong>Nom de votre région</strong>".$xml->geoplugin_regionName ."</li>";
                    echo "<li><strong>Code de la zone :</strong>".$xml->geoplugin_areaCode ."</li>";
                    echo "<li><strong>Code DMA :</strong>".$xml->geoplugin_dmaCode ."</li>";
                    echo "<li><strong>Code pays :</strong>".$xml->geoplugin_countryCode ."</li>";
                    echo "<li><strong>Dans l'Union européenne :</strong>".$xml->geoplugin_inEU ."</li>";
                    echo "<li><strong>Taux de TVA en Europe :</strong>".$xml->geoplugin_euVATrate ."</li>";
                    echo "<li><strong>Code de continent :</strong>".$xml->geoplugin_continentCode ."</li>";
                    echo "<li><strong>Latitude :</strong>".$xml->geoplugin_latitude ."</li>";
                    echo "<li><strong>Longitude :</strong>".$xml->geoplugin_longitude ."</li>";
                    echo "<li><strong>Rayon de précision de la localisation :</strong>".$xml->geoplugin_locationAccuracyRadius ."</li>";
                    echo "<li><strong>Zone horaire :</strong>".$xml->geoplugin_timezone ."</li>";
                    echo "<li><strong>Code de devise :</strong>".$xml->geoplugin_currencyCode ."</li>";
                    echo "<li><strong>Symbole de devise :</strong>".$xml->geoplugin_currencySymbol ."</li>";
                    echo "<li><strong>Symbole de devise en UTF-8 :</strong>".$xml->geoplugin_currencySymbol_UTF8 ."</li>";
                    echo "<li><strong>Convertisseur de devise :</strong>".$xml->geoplugin_currencyConverter ."</li>";
            
                echo "</ul>";


            ?>

        </section>


    </main>


<?php
    require "./include/footer.inc.php"; 
?>