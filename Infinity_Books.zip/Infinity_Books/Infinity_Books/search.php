<?php
if (isset($_GET['search'])) {
    $search = urlencode($_GET['search']);
    $search_option = isset($_GET['search_option']) ? $_GET['search_option'] : 'name';
    if (!empty($search)) {
        $apiKey = 'AIzaSyDLL3CRwM2_DF-bRow-WYv8yYzBEZQuBzQ';
        $startIndex = isset($_GET['start']) ? $_GET['start'] : 0;
        $maxResults = 10;
        if ($search_option == 'name') {
            $url = "https://www.googleapis.com/books/v1/volumes?q=$search&startIndex=$startIndex&maxResults=$maxResults&key=$apiKey";
        } else if ($search_option == 'isbn') {
            $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:$search&startIndex=$startIndex&maxResults=$maxResults&key=$apiKey";
        }else if ($search_option == 'auteur') {
            $url = "https://www.googleapis.com/books/v1/volumes?q=authors:$search&startIndex=$startIndex&maxResults=$maxResults&key=$apiKey";
        }
        $response = file_get_contents($url);
        $data = json_decode($response, true);

        $view = isset($_GET['view']) ? $_GET['view'] : 'general';



        echo "<div class='book-container'>\n";

        if (isset($data['items'])) {
            foreach ($data['items'] as $book) {
                $id = isset($book['id']) ? $book['id'] : 'ID indisponible';
                $title = isset($book['volumeInfo']['title']) ? $book['volumeInfo']['title'] : 'Titre indisponible';
                $authors = isset($book['volumeInfo']['authors']) ? implode(', ', $book['volumeInfo']['authors']) : 'Auteur(s) indisponible(s)';
                $description = isset($book['volumeInfo']['description']) ? $book['volumeInfo']['description'] : 'Description indisponible';
                if (isset($book['volumeInfo']['imageLinks']['thumbnail'])) {
                    $image = $book['volumeInfo']['imageLinks']['thumbnail'];
                } else {
                    $image = 'images/none.png';
                }
                $isbn = isset($book['volumeInfo']['industryIdentifiers'][0]['identifier']) ? $book['volumeInfo']['industryIdentifiers'][0]['identifier'] : 'ISBN indisponible';
                $publishedDate = isset($book['volumeInfo']['publishedDate']) ? $book['volumeInfo']['publishedDate'] : 'Date de publication indisponible';
                $publisher = isset($book['volumeInfo']['publisher']) ? $book['volumeInfo']['publisher'] : 'Maison d\'édition indisponible';



                echo "<section class='book'> \n";
                $image= str_replace('&', '&amp;', $image);
                if ($image != '') {
                    echo "<figure class='book-image'> \n";
                    echo "<img src='$image' alt='Image de couverture de livre.' /> \n";
                    echo "<figcaption></figcaption> \n";
                    echo "</figure> \n";
                }
                echo "<div class='book-details'> \n";
                echo "<h2>$title</h2> \n";
                echo "<span><strong>Par</strong> $authors</span> \n";
                echo "<span><strong>ISBN: </strong> $isbn </span>\n";
                echo "<a href='details.php?id=$id' class='show-more'>Afficher plus</a> \n";


                $bookInLibrary = false;
                if (isset($_COOKIE['library'])) {
                    $library = json_decode($_COOKIE['library'], true);
                    $bookInLibrary = array_key_exists($id, $library);
                }

                if ($bookInLibrary) {
                    echo "<a href='?remove=$id' class='show-more'>Retirer de ma bibliothèque</a>\n";
                } else {
                    echo "<a href='?add=$id&amp;title=" . urlencode($title) . "&amp;authors=" . urlencode($authors) . "&amp;image=" . urlencode($image) . "&amp;isbn=" . urlencode($isbn) . "&amp;id=" . urlencode($id) . "' class='show-more' title='Ajouter ce livre à votre collection'>Ajouter à ma bibliothèque</a>\n";                        
                }

                echo "</div> \n";
                echo "</section> \n";
               
            }

            
            $totalItems = isset($data['totalItems']) ? $data['totalItems'] : 0;
            $currentPage = floor($startIndex / $maxResults) + 1;
            $totalPages = ceil($totalItems / 10);
            $nextStartIndex = $startIndex + $maxResults;
            $prevStartIndex = $startIndex - $maxResults;
  
            echo "<div class='pagination'>\n";
  
            if ($prevStartIndex >= 0) {
                echo "<a href='?search=$search&amp;start=$prevStartIndex&amp;view=$view' class='previous'>Précédent</a>\n";
            }
            //ligne à enlever 
            //echo "<span class='current-page'>$currentPage / $totalPages</span>";
  
            if ($nextStartIndex < $totalItems) {
                echo "<a href='?search=$search&amp;start=$nextStartIndex&amp;view=$view' class='next'>Suivant </a>\n";
            }
  
            echo "</div>\n";
        } else {
            echo "<span>Aucun livre trouvé.</span>\n";
        }
  
        echo "</div>\n";
    } else {
        echo "<span>Veuillez entrer un terme de recherche.</span>\n";
    }
}

?>

